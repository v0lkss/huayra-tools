# BLOSSOM

A little theme for your Spotify client.

![1](https://github.com/spicetify/spicetify-themes/assets/72624799/4e545661-a164-469a-a10c-c1fcba40ab72)
![2](https://github.com/spicetify/spicetify-themes/assets/72624799/263ebbd2-b383-47b4-8bcf-1a9c4d5152c1)

Made for a dark theme look thats pleasing to the eye.

By Robatortas

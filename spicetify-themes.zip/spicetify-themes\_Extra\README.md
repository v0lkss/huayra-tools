# Extras

This folder contains additional resources for tweaking the look of
Spotify. More info in each subfolder.

| Folder      | Description |
| ----------- | ----------- |
| **SpotifyNoControl**      | Hides Spotify Window controls |

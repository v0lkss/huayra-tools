# Default

Default look of Spotify with different color schemes.

## Screenshot

![screenshot](./ocean.png)

## Info

### Ocean

Part of material ocean themes, [checkout here](https://github.com/material-ocean) for the same theme for different applications. By @Blacksuan19

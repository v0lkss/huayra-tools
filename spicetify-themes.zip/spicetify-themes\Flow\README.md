# Flow

## Screenshots

### Ocean
<img src="https://raw.githubusercontent.com/spicetify/spicetify-themes/master/Flow/screenshots/ocean.png" alt="img"> 


### Pink
<img src="https://raw.githubusercontent.com/spicetify/spicetify-themes/master/Flow/screenshots/pink.png" alt="img"> 


### Silver
<img src="https://raw.githubusercontent.com/spicetify/spicetify-themes/master/Flow/screenshots/silver.png" alt="img"> 


### Violet
<img src="https://raw.githubusercontent.com/spicetify/spicetify-themes/master/Flow/screenshots/violet.png" alt="img"> 

## Author
Made by:
* https://github.com/Ruixi-Zhang
* https://github.com/yslDevelop
* https://github.com/ian-Liaozy
* https://github.com/alexcasieri30
